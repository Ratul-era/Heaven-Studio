// Heaven Studio starter site interactions
// YouTube auto-feed: create an API key in Google Cloud Console and set it below.
// Never put a private API key or Facebook Page access token in a public website.
const YOUTUBE_API_KEY = ""; // Paste a restricted YouTube Data API v3 key here
const YOUTUBE_CHANNEL_ID = ""; // Optional: channel ID beginning with UC. Resolve from the channel if needed.
const YOUTUBE_HANDLE = "HeavenArchitects";
const YOUTUBE_REFRESH_MS = 15 * 60 * 1000;

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");
menuToggle?.addEventListener("click", () => {
  const open = menuToggle.getAttribute("aria-expanded") !== "true";
  menuToggle.setAttribute("aria-expanded", String(open));
  nav.classList.toggle("open", open);
});
nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
}));

document.getElementById("year").textContent = new Date().getFullYear();

const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".project-card");
filters.forEach(button => button.addEventListener("click", () => {
  filters.forEach(f => f.classList.toggle("active", f === button));
  const category = button.dataset.filter;
  cards.forEach((card, index) => {
    const show = category === "all" || card.dataset.category === category;
    card.classList.toggle("hidden", !show);
    if (show) card.style.animationDelay = `${(index % 3) * 70}ms`;
  });
}));

const modal = document.getElementById("projectModal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalType = document.getElementById("modalType");
function openProject(card) {
  const img = card.querySelector("img");
  modalImage.src = img.src;
  modalImage.alt = img.alt;
  modalTitle.textContent = card.dataset.title;
  modalType.textContent = card.dataset.type;
  modal.showModal();
}
cards.forEach(card => {
  card.addEventListener("click", () => openProject(card));
  card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openProject(card); } });
});
document.querySelector(".modal-close").addEventListener("click", () => modal.close());
modal.addEventListener("click", e => { if (e.target === modal) modal.close(); });
document.getElementById("modalContact").addEventListener("click", () => modal.close());

// Scroll reveal and reduced-motion-aware parallax.
const revealTargets = document.querySelectorAll(".section-kicker, .intro-content, .stats-row, .section-heading, .service-row, .social-panel, .project-card");
revealTargets.forEach(el => el.classList.add("reveal"));
const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) { entry.target.classList.add("visible"); observer.unobserve(entry.target); }
}), { threshold: 0.12 });
revealTargets.forEach(el => observer.observe(el));

const parallaxItems = document.querySelectorAll("[data-parallax]");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let ticking = false;
function updateParallax() {
  if (!reducedMotion) {
    const vh = window.innerHeight;
    parallaxItems.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.bottom > -150 && rect.top < vh + 150) {
        const speed = Number(el.dataset.parallax || 0.1);
        const shift = (rect.top + rect.height / 2 - vh / 2) * -speed;
        el.style.translate = `0 ${shift.toFixed(1)}px`;
      }
    });
  }
  ticking = false;
}
window.addEventListener("scroll", () => { if (!ticking) { requestAnimationFrame(updateParallax); ticking = true; } }, { passive: true });
window.addEventListener("resize", updateParallax);
updateParallax();

const glow = document.querySelector(".cursor-glow");
if (glow && matchMedia("(pointer:fine)").matches) {
  window.addEventListener("pointermove", e => {
    glow.style.left = `${e.clientX}px`; glow.style.top = `${e.clientY}px`; glow.style.opacity = ".9";
  }, { passive: true });
  document.addEventListener("pointerleave", () => glow.style.opacity = "0");
}

// Public YouTube uploads are fetched through YouTube Data API v3.
// Polling every 15 minutes keeps the page refreshed without excessive API calls.
async function loadYouTube() {
  const feed = document.getElementById("youtubeFeed");
  if (!YOUTUBE_API_KEY) return; // Helpful placeholder remains visible until configured.
  try {
    let channelId = YOUTUBE_CHANNEL_ID;
    if (!channelId) {
      const channelRes = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&forHandle=${encodeURIComponent(YOUTUBE_HANDLE)}&key=${encodeURIComponent(YOUTUBE_API_KEY)}`);
      const channelData = await channelRes.json();
      if (!channelRes.ok || !channelData.items?.length) throw new Error("Could not resolve YouTube channel. Set YOUTUBE_CHANNEL_ID in script.js.");
      channelId = channelData.items[0].id;
    }
    const channelRes = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${encodeURIComponent(channelId)}&key=${encodeURIComponent(YOUTUBE_API_KEY)}`);
    const channelData = await channelRes.json();
    const uploadsId = channelData.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
    if (!uploadsId) throw new Error("Uploads playlist not found.");
    const videosRes = await fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=4&playlistId=${encodeURIComponent(uploadsId)}&key=${encodeURIComponent(YOUTUBE_API_KEY)}`);
    const videosData = await videosRes.json();
    if (!videosRes.ok) throw new Error(videosData.error?.message || "YouTube feed request failed.");
    const videos = (videosData.items || []).filter(v => v.snippet?.resourceId?.videoId);
    if (!videos.length) throw new Error("No public uploads found.");
    feed.innerHTML = `<div class="youtube-videos">${videos.map(v => {
      const id = v.snippet.resourceId.videoId;
      const title = escapeHTML(v.snippet.title);
      const thumb = v.snippet.thumbnails?.medium?.url || v.snippet.thumbnails?.default?.url || `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;
      const date = v.snippet.publishedAt ? new Date(v.snippet.publishedAt).toLocaleDateString(undefined, { year:"numeric", month:"short", day:"numeric" }) : "Latest upload";
      return `<a class="youtube-video" href="https://www.youtube.com/watch?v=${encodeURIComponent(id)}" target="_blank" rel="noopener"><img src="${thumb}" alt="" loading="lazy"><strong>${title}</strong><span>${date} · Watch video ↗</span></a>`;
    }).join("")}</div>`;
  } catch (err) {
    console.error("YouTube feed:", err);
    feed.innerHTML = `<div class="feed-placeholder"><p>Videos could not be loaded.</p><small>${escapeHTML(err.message)} Check the API key, channel ID and quota settings.</small><a class="text-link" href="https://www.youtube.com/@HeavenArchitects" target="_blank" rel="noopener">Open YouTube channel ↗</a></div>`;
  }
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
loadYouTube();
if (YOUTUBE_API_KEY) window.setInterval(loadYouTube, YOUTUBE_REFRESH_MS);
