# Heaven Studio website

A responsive, minimalist architecture portfolio starter built with plain HTML, CSS and JavaScript.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser. For the YouTube API fetch to work reliably, use a local server such as VS Code Live Server or `python -m http.server 8000`.
3. The website is static and can be deployed to Netlify, Vercel, GitHub Pages, or standard web hosting.

## What's included
- Responsive navigation and mobile menu
- 3D-inspired hero composition, layered image depth, cursor glow and parallax
- Animated scroll reveals
- Project category filters and interactive project detail modal
- Services, studio story, social links and contact CTA
- Optional YouTube latest uploads feed via YouTube Data API v3
- Facebook page link and secure-integration notes

## YouTube latest uploads
1. Create a project in Google Cloud Console and enable **YouTube Data API v3**.
2. Create an API key and restrict it to YouTube Data API v3 and your production website referrers.
3. In `script.js`, set `YOUTUBE_API_KEY`. The handle is prefilled as `HeavenArchitects`; if handle lookup does not work, set `YOUTUBE_CHANNEL_ID` to the channel's UC... ID.
4. The frontend checks for new uploads every 15 minutes. It requires internet access and an active API key/quota.

The official YouTube Data API requires a key or OAuth token for requests. Public client-side keys are visible to visitors, so restrict the key by API and HTTP referrer. For stricter security, move API requests to a server-side endpoint.

## Facebook live posts
This starter links directly to the official Facebook Page but does not pretend to provide a live post feed. For a true automatic feed, connect Meta's Graph API from a small backend using approved Page permissions and a securely stored Page access token, or use an approved social-feed provider. Never publish a Page access token in `script.js` or other browser code. Facebook embeds may be restricted by Page settings, consent or browser privacy settings.

## Before launch
- Replace the six sample portfolio images and their titles with actual Heaven Studio project photos and accurate project details. The current imagery is illustrative and must not be presented as completed client work.
- Confirm WhatsApp contact number and update the link in `index.html` if needed.
- Add actual office address, email, service areas, project descriptions and privacy policy.
- For production, use optimized locally hosted images, your own domain, analytics/SEO metadata and a backend contact form.
- The logo included is the uploaded logo image supplied with the request.

## Reference
Website structure and architecture-service categories were informed by the reference site: https://greenarchitectbd.com/
